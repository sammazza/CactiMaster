﻿var numExercises = 5;

window.onload = function onPageLoad() {
    fillNumbers();
}

function checkAnswers() {
    var score = 0;
    for (var i = 1; i <= numExercises; i++) {

        var n1 = parseInt(document.getElementById("num" + i + "1").value); // 11, 12, 13
        var n2 = parseInt(document.getElementById("num" + i + "2").value);  // 21, 22, 23..
        var userAnswer  = parseInt(document.getElementById("anwser" + i).value);

        
        var correctAnswer = 0;
        switch (i) {
            case 1:
                correctAnswer = n1 + n2;
                break;
            case 2:
                correctAnswer = n1 - n2;
                break;
            case 3:
                correctAnswer = n1 * n2;
                break;
            case 4:
                correctAnswer = Math.floor(n1 / n2);
                break;
            case 5:
                correctAnswer = n1 % n2;
                break;
        }

        var msg = document.getElementById("msg" + i);
        var icon = document.getElementById("imgresult" + i);

        if (userAnswer == correctAnswer) {
            msg.value = "Nice!"
            icon.setAttribute("src", "Images/v-mark.png");
            score += 1;
        }
        else {
            msg.value = "Almost, please try again"
            icon.setAttribute("src", "Images/x-mark.png");
        }
    }

    var elmtScore = document.getElementById("score");
    elmtScore.innerHTML = "You answered " + score + " correct answers";
}




function fillNumbers() {
    for (var i = 1; i <= numExercises; i++) {
        var n1 = document.getElementById("num" + i + "1"); // 11, 12, 13
        var n2 = document.getElementById("num" + i + "2");  // 21, 22, 23..
        n1.value = getRandomNumber(2);
        n2.value = getRandomNumber(1);
    }
}

function getRandomNumber(numDigits) {
    var num = parseInt(Math.random() * 10);

    if (numDigits == 2)
        return num + 10
    return num + 1;
}