﻿//const { ellipsis } = require("modernizr");

function hasBadChars(text, elementError) {
    var badChar = "0123456789~!@#$%^&*()_+=|[]{};:?><,.` ";

    for (var i = 0; i < badChar.length; i++) {
        if (text.indexOf(badChar[i]) != -1) {
            elementError.innerHTML = "Invalid character " + badChar[i] + " in field";
            return true;
        }
    }
    if (text.indexOf("'") != -1) {
        elementError.innerHTML = "Single quote not allowed in field";
        return true;

    }
    if (text.indexOf('"') != -1) {
        elementError.innerHTML = "Double quote not allowed";
        return true;
    }
    return false;
}

function hasHebrewLetter(text, elementError) {
    for (var i = 0; i < text.length; i++) {
        if (text[i] >= 'א' && text[i] <= 'ת') {
            elementError.innerHTML = "All letters must be English letters";
            return true;
        }
    }
    return false;
}

function checkname(name, elementError)
{
    //fname = fname.trim();

    /* because of trim we no longer need this test
    if (name.length == "") {
        document.getElementById(elementError).innerHTML = "Field cannot be empty";
        return false;
    }
    */
    if (name.length < 2) {
        document.getElementById(elementError).innerHTML = "Field must have at least 2 letters";
        return false;
    }

    if (hasBadChars(name, document.getElementById(elementError))) {
        return false;
    }

    if (hasHebrewLetter(name, document.getElementById(elementError))) {
        return false;
    }

    return true;

}

function checkuname(uname) {
    return checkname(uname, "erroruname");
}

function checkfname(fname) {

    return checkname(fname, "errorfname");

    //fname = fname.trim();

    /* because of trim we no longer need this test
    if (fname.length == "") {
        document.getElementById("errorfname").innerHTML = "Field cannot be empty";
        return false;
    }
    */
    if (fname.length < 2) {
        document.getElementById("errorfname").innerHTML = "First name must have at least 2 letters";
        return false;
    }

    if (hasBadChars(fname, document.getElementById("errorfname"))) {
        return false;
    }

    if (hasHebrewLetter(fname, document.getElementById("errorfname"))) {
        return false;
    }

    return true;
}

function checklname(lname) {
    return checkname(lname, "errorlname");

    //lname = lname.trim();
    /*
    if (lname == "") {
        document.getElementById("errorlname").innerHTML = " שדה השם לא יכול להיות ריק";
        return false;
    }
    */
    if (lname.length < 2) {
        document.getElementById("errorlname").innerHTML = "השדה חייב להיות באורך של 2 תווים לפחות";
        return false;
    }

    if (hasBadChars(lname, document.getElementById("errorlname"))) {
        return false;
    }

    if (hasHebrewLetter(lname, document.getElementById("errorlname"))) {
        return false;
    }

    return true;
}

function checkumail(umail) {
    if (umail == "") {
        document.getElementById("errormail").innerHTML = "Email cannot be empty";
        return false;
    }
    if (umail.indexOf('@') == -1) {
        document.getElementById("errormail").innerHTML = "Email address must include @";
        return false;
    }
    if (umail.indexOf('@') != umail.lastIndexOf('@')) {
        document.getElementById("errormail").innerHTML = "Email address must include only one @";
        return false;
    }
    if (umail.indexOf('@') == 0 || umail.indexOf('@') == umail.length) {
        document.getElementById("errormail").innerHTML = "@ cannot be first or last";
        return false;
    }
    if (hasHebrewLetter(umail, document.getElementById("errormail"))) {
        return false;
    }


    if ((umail.split("@").length == 2) &&
        (umail.indexOf("@") != -1) &&
        (umail.indexOf(".") != 0) &&
        (umail.lastIndexOf(".") != umail.length - 1) &&
        (umail.length >= 5 && umail.length <= 30))
        ;
    else {
        document.getElementById("errormail").innerHTML = "Invalid email address, must include @ and a dot (.)";
        return false;
    }

    return true;
}

function checkpassword(password) {
    if (password.length < 6) {
        document.getElementById("errorpassword").innerHTML = "password must be have at least 6 characters";
        return false;
    }
    return true;
}

function checkverifypassword(password, verifypassword) {
    if (password != verifypassword) {
        document.getElementById("errorverifypassword").innerHTML = "Passwords do not match";
        return false;
    }
    return true;
}

function checkage(age) {
    if (isNaN(age)) {
        document.getElementById("erroryearborn").innerHTML = "Please select a year";
        return false;
    }
    return true;
}

function checkTZ(tzid) {
    var index = 8;
    var chkdigit = Number(tzid[index]);
    var mul = 2;
    var sum = 0;
    var tmp = 0;
    index--;

    while (index >= 0) {

        tmp = mul * Number(tzid[index]);
        if (tmp >= 10)
            sum = sum + tmp % 10 + Math.floor(tmp / 10);
        else
            sum = sum + mul * Number(tzid[index]);

        if (mul == 2)
            mul = 1;
        else
            mul = 2;
        index--;
    }
    if (10 - sum % 10 == chkdigit)
        return true;

    return false;
}

function isOnlyDigits(tzid) {

    if (isNaN(tzid))
        return false;
    return true;
    /**
        numchar = "0123456789";
        for (var i = 0; i < tzid.length; i++)
        if (numchar.indexOf(tzid[i]) == -1)
            return false;
    **/
}

function checktzid(tzid) {
    //tzid = tzid.trim();

    if (isNaN(tzid)) {
        document.getElementById("uiderror").innerHTML = "Only digits allowed";
        return false;
    }

    if (tzid.length != 9) {
        document.getElementById("uiderror").innerHTML = "ID must have exactly 9 digits";
        return false;
    }
    /*
    if (tzid == "") {
        document.getElementById("uiderror").innerHTML = "שדה תעודת זהות אינו יכול להיות ריק";
        return false;
    }
    */
    if (!isOnlyDigits(tzid)) {
        document.getElementById("uiderror").innerHTML = "ID must be digits only";
        return false;
    }

    if (checkTZ(tzid) == false) {
        document.getElementById("uiderror").innerHTML = "מספר תעודת זהות אינו תקין אנא הכנס שוב";
        return false;
    }
    return true;
}

function checkphone(prefix, phone) {
    if (isNaN(prefix)) {
        document.getElementById("errorphone").innerHTML = "Please select prefix";
        return false;
    }
    if (isNaN(phone)) {
        document.getElementById("errorphone").innerHTML = "Phone number must be all digits";
        return false;
    }
    if (phone.length != 7) {
        document.getElementById("errorphone").innerHTML = "Phone number must be 7 digits";
        return false;
    }
    return true;

}

function validateForm() {
    // קריאת ערכי שדות הטופס הנבחרים
    resetForm();

    var uname = regform.uname.value.trim();
    var fname = regform.fname.value.trim();
    var lname = regform.lname.value.trim();
    var umail = regform.email.value.trim();
    var password = regform.password.value.trim();
    var verifypassword = regform.verifypassword.value.trim();
    var age = regform.yearborn.value.trim();
    var tzid = regform.tzid.value.trim();
    var prefix = regform.prefix.value.trim();
    var phone = regform.phone.value.trim();

    // ביצוע בדיקות תקינות על השדות השונים
    var check0 = checkuname(uname);
    var check1 = checkfname(fname);
    var check2 = checklname(lname);
    var check3 = checkumail(umail);
    var check4 = checkpassword(password);
    var check4_1 = checkverifypassword(password, verifypassword);
    var check5 = checkage(age);
    var check6 = checktzid(tzid);
    var check7 = checkphone(prefix, phone)

    // אם כל הבדיקות תקינות החזר אמת אחרת שקר
    if (check0 && check1 && check2 && check3 && check4 && check4_1 && check5 && check6 && check7) 
        return true;

    return false;
}

function resetForm() {
    clearErrorsMessages();
}

function clearErrorsMessages() {
    document.getElementById("erroruname").innerHTML = "";
    document.getElementById("errorfname").innerHTML = "";
    document.getElementById("errorlname").innerHTML = "";
    document.getElementById("uiderror").innerHTML = "";
    document.getElementById("errormail").innerHTML = "";
    document.getElementById("errorpassword").innerHTML = "";
    document.getElementById("errorverifypassword").innerHTML = "";
    document.getElementById("erroryearborn").innerHTML = "";
    document.getElementById("errorphone").innerHTML = "";
}




/*********

function checkForm() {
 
    var fName = document.getElementById("uname").value;
    if (fName.length < 3) {
        var elmt = document.getElementById("erroruname");
        elmt.value = "bad";
        elmt.style.display = "inline";
        return false;
    }
    else {
        document.getElementById("erroruname").style.display = "inline";
        return true;
    }
}

 *********/