
aaa111	Sam	Mazza	aaa111@gmail.com	2007	M	050	5551111	Beer-Sheva	T	F	T	T	aaa111	F
bbb222	Bob	Bally	bob@hotmail.com	2002	F	057	5551212	Haifa	F	T	F	T	bbb222	F
ccc333	Charly	Chaplin	charly@walla.com	2003	M	03	5551313	Ashkelon	T	T	F	F	ccc333	F
ddd444	David	Davisdon	david@gmail.com	2004	M	04	5551414	Haifa	F	F	T	T	ddd444	F
eee555	Eddy	Elon	ee@gmail.com	2005	M	09	5551515	Jerusalem	F	T	F	T	eee555	F
fff666	Franky	Freaky	franky@gmail.com	2006	F	03	5551616	Askelon	F	T	T	F	fff666	F
ggg777	Gina	Balerina	gina@wall.com	1999	F	054	5551717	Beer-Sheva	F	T	T	F	ggg777	F
hhh888	Hila	Bila	hilabila@gmail.com	1999	F	02	5551818	Natanya	F	F	F	T	hhh888	F
iii999	Ivan	Agadol	ivan@hotmail.com	2005	M	02	5551919	Jerusalem	T	T	T	T	iii999	F
Sam	Sam	Mazza	sam@gmail.com	2001	M	054	7321435	Tel-Aviv	T	T	F	F	123456	T
NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL	NULL






INSERT INTO [dbo].[usersTbl] ([uName], [fName], [lName], [email], [yearBorn], [gender], [prefix], [phone], [city], [hob1], [hob2], [hob3], [hob4], [password], [isAdmin]) VALUES (N'aaa111', N'Sam', N'Mazza', N'aaa111@gmail.com', 2007, N'M', N'050', N'5551111', N'Beer-Sheva', N'T', N'F', N'T', N'T', N'aaa111', N'F')
INSERT INTO [dbo].[usersTbl] ([uName], [fName], [lName], [email], [yearBorn], [gender], [prefix], [phone], [city], [hob1], [hob2], [hob3], [hob4], [password], [isAdmin]) VALUES (N'bbb222', N'Bob', N'Bally', N'bob@hotmail.com', 2002, N'F', N'057', N'5551212', N'Haifa', N'F', N'T', N'F', N'T', N'bbb222', N'F')
INSERT INTO [dbo].[usersTbl] ([uName], [fName], [lName], [email], [yearBorn], [gender], [prefix], [phone], [city], [hob1], [hob2], [hob3], [hob4], [password], [isAdmin]) VALUES (N'ccc333', N'Charly', N'Chaplin', N'charly@walla.com', 2003, N'M', N'03', N'5551313', N'Ashkelon', N'T', N'T', N'F', N'F', N'ccc333', N'F')
INSERT INTO [dbo].[usersTbl] ([uName], [fName], [lName], [email], [yearBorn], [gender], [prefix], [phone], [city], [hob1], [hob2], [hob3], [hob4], [password], [isAdmin]) VALUES (N'ddd444', N'David', N'Davisdon', N'david@gmail.com', 2004, N'M', N'04', N'5551414', N'Haifa', N'F', N'F', N'T', N'T', N'ddd444', N'F')
INSERT INTO [dbo].[usersTbl] ([uName], [fName], [lName], [email], [yearBorn], [gender], [prefix], [phone], [city], [hob1], [hob2], [hob3], [hob4], [password], [isAdmin]) VALUES (N'eee555', N'Eddy', N'Elon', N'ee@gmail.com', 2005, N'M', N'09', N'5551515', N'Jerusalem', N'F', N'T', N'F', N'T', N'eee555', N'F')
INSERT INTO [dbo].[usersTbl] ([uName], [fName], [lName], [email], [yearBorn], [gender], [prefix], [phone], [city], [hob1], [hob2], [hob3], [hob4], [password], [isAdmin]) VALUES (N'fff666', N'Franky', N'Freaky', N'franky@gmail.com', 2006, N'F', N'03', N'5551616', N'Askelon', N'F', N'T', N'T', N'F', N'fff666', N'F')
INSERT INTO [dbo].[usersTbl] ([uName], [fName], [lName], [email], [yearBorn], [gender], [prefix], [phone], [city], [hob1], [hob2], [hob3], [hob4], [password], [isAdmin]) VALUES (N'ggg777', N'Gina', N'Balerina', N'gina@wall.com', 1999, N'F', N'054', N'5551717', N'Beer-Sheva', N'F', N'T', N'T', N'F', N'ggg777', N'F')
INSERT INTO [dbo].[usersTbl] ([uName], [fName], [lName], [email], [yearBorn], [gender], [prefix], [phone], [city], [hob1], [hob2], [hob3], [hob4], [password], [isAdmin]) VALUES (N'hhh888', N'Hila', N'Bila', N'hilabila@gmail.com', 1999, N'F', N'02', N'5551818', N'Natanya', N'F', N'F', N'F', N'T', N'hhh888', N'F')
INSERT INTO [dbo].[usersTbl] ([uName], [fName], [lName], [email], [yearBorn], [gender], [prefix], [phone], [city], [hob1], [hob2], [hob3], [hob4], [password], [isAdmin]) VALUES (N'iii999', N'Ivan', N'Agadol', N'ivan@hotmail.com', 2005, N'M', N'02', N'5551919', N'Jerusalem', N'T', N'T', N'T', N'T', N'iii999', N'F')
INSERT INTO [dbo].[usersTbl] ([uName], [fName], [lName], [email], [yearBorn], [gender], [prefix], [phone], [city], [hob1], [hob2], [hob3], [hob4], [password], [isAdmin]) VALUES (N'Sam', N'Sam', N'Mazza', N'sam@gmail.com', 2001, N'M', N'054', N'7321435', N'Tel-Aviv', N'T', N'T', N'F', N'F', N'123456', N'T')
